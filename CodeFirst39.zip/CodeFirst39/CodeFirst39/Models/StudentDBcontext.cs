﻿using Microsoft.EntityFrameworkCore;

namespace CodeFirst39.Models
{
    //DBContext class should to be inherit that interacts with database.
    public class StudentDBcontext : DbContext
    {
        //make constructor here
        //write Ctor and tab 2 times
        // use of base class is to call parentclass's Constructor
        public StudentDBcontext(DbContextOptions options) : base(options) //option will be sto
        {
                
        }
        //model 'Student' na type no DbSet banavyo teni property nu name StudentTab aaj table nu name hse
        public DbSet<Student> StudentsTab{ get; set; }
    }
}
