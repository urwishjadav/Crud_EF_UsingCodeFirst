﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CodeFirst39.Models
{
    public class Student
    {
        [Key]
        public int Id { get; set; }

        [Column("Stud_Name",TypeName ="varchar(100)")]
        [Required]
        public string Name{ get; set; }

        [Required]
        public string State { get; set; }

        [Required]
        public int? Age{ get; set; }
    }
}
