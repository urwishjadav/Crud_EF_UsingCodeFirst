﻿using CodeFirst39.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using System.Reflection.Metadata.Ecma335;

namespace CodeFirst39.Controllers
{
    public class HomeController : Controller
    {
        private readonly StudentDBcontext studentDB;

        //private readonly ILogger<HomeController> _logger;

        //public HomeController(ILogger<HomeController> logger)
        //{
        //    _logger = logger;
        //}

        public HomeController(StudentDBcontext studentDB)
        {
            this.studentDB = studentDB; //object
        }

        public IActionResult Index()
        {
            var stddata = studentDB.StudentsTab.ToList();
            return View(stddata);
        }

        public IActionResult Create()
        {
            return View();
        }

        [ValidateAntiForgeryToken]
        [HttpPost]
        public async Task <IActionResult> Create(Student std)
        {
            if (ModelState.IsValid)
            {
                await studentDB.StudentsTab.AddAsync(std);
                await studentDB.SaveChangesAsync();
                TempData["CreatedMsg"] = "Data Inserted...";
                return RedirectToAction("Index","Home"); // Index current ma che tene home ma redirect krva
            }
            return View(std);
        }

        public async Task<IActionResult>Details(int? id)
        {
            if (id == null || studentDB.StudentsTab == null)
            {
                return NotFound(); //inbuilt function to load not found page 
            }
            var stdData = await studentDB.StudentsTab.FirstOrDefaultAsync(z => z.Id == id);
            if (stdData == null)
            {
                return NotFound();
            }
            return View(stdData);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || studentDB.StudentsTab == null) 
            {
                return NotFound();
            }
            var stdData = await studentDB.StudentsTab.FindAsync(id);
            if (stdData == null)
            {
                return NotFound();
            }
            return View(stdData);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]

        public async Task<IActionResult> Edit(int? id , Student std)
        {
            //parameter id and student na obj 'std' ni id same nai thay to not found.
            if(id != std.Id)
            {
                return NotFound();
            }
            // and match thai to modelstate valid and further code will run
            if (ModelState.IsValid)
            {
                studentDB.Update(std);
                await studentDB.SaveChangesAsync();
                TempData["UpdateMsg"] = "Data Updated...";
                return RedirectToAction("Index","Home");
            }
            return View(std);
        }

        public async Task<IActionResult> Delete(int? id)
        {

            if (id == null || studentDB.StudentsTab == null)
            {
                return NotFound();
            }
            var stdData = await studentDB.StudentsTab.FirstOrDefaultAsync(z => z.Id == id);
            if (stdData == null)
            {
                return NotFound();
            }
            return View(stdData);
        }

        [ValidateAntiForgeryToken]
        [HttpPost,ActionName("Delete")]
        //apdi method post nu name alg che to request to delete maj jse to te request
        // delete maj send krva action name ma 'Delete' define kryu
        public async Task <IActionResult> DeleteConfirm(int? id)
        {
            // id thi find krva k kayo data id thi delete krvano che
            var stdData = await studentDB.StudentsTab.FindAsync(id);
            if (stdData != null) //data null na hoi to remove kro
            {
                studentDB.StudentsTab.Remove(stdData);
            }
            await studentDB.SaveChangesAsync();
            TempData["DeleteMsg"] = "Data Deleted...";
            return RedirectToAction("Index", "Home");
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}